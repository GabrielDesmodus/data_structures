#include<stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL,"Portuguese");

    int w=0, x=0, y=0, z=0;
    int *salBruto=0, *salFamilia=0, *vantagens=0;
    float *inss=0, *irpf=0, *deduc=0;
    float salBruto2=0, taxaIr=0;

    printf("Insira o n�mero de horas: \n");
    scanf("%d", &w);
    printf("Insira o sal�rio por hora: \n");
    scanf("%d", &x);
    printf("Insira o n�mero de filhos: \n");
    scanf("%d", &y);
    printf("Insira o valor por filho: \n");
    scanf("%d", &z);

    calcVantagens(&salBruto, &salFamilia, &vantagens,w,x,y,z);

    printf("\nSal�rio Bruto: \n%d", salBruto);
    printf("\nSal�rio da Fam�lia: \n%d", salFamilia);
    printf("\nVantagens: \n%d", vantagens);

    printf("\nInsira o valor da taxa de Imposto de Renda\n");
    scanf("%f", &taxaIr);
    printf("\nInsira o valor do sal�rio Bruto\n");
    scanf("%f", &salBruto2);

    calcDeduc(&inss, &irpf, &deduc, taxaIr, salBruto2);

    printf("\nINSS: \n%f", inss);
    printf("\nIRPF: \n%f", irpf);
    printf("\nDedu��es: \n%f", deduc);

    return 0;
}
