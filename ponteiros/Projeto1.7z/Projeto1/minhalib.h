void calcVantagens(int *enderSalBruto, int *enderFamilia, int *enderVantagens, int numHoras, int salHora, int numFilhos, int valorPorFilho);
void calcDeduc(float *enderInss, float *enderIrpf, float *enderDeduc, float taxaIr, float salBruto2);
